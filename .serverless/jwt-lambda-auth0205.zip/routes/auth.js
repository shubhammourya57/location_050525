const express = require('express');
const router = express.Router();
const { register, login,location } = require('../controllers/authController');
const verifyToken = require('../middleware/authMiddleware');
// const verifyToken = require('../middlewares/verifyToken')
router.post('/register', register);
router.get("/api/location/:locationID",verifyToken, location);
// router.post('/login', login);

module.exports = router;
