const jwt = require('jsonwebtoken');
const fs = require("fs");
const path = require("path");
// Dummy PublicAlerts
class PublicAlerts {
    async loadLocationById(req, res, { locationId, type }) {
      return {
        locations: [
          {
            id: locationId,
            name: "Test Location",
            logo: "logo.png",
            address: "123 Main St",
            latitude: 12.34,
            longitude: 56.78,
            polygon: [],
            radius: 100,
            zoom: 15,
          },
        ],
      };
    }
  }
const createToken = (user) => {
  return jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
};

exports.register = async (req, res) => {
  const { email, password } = req.body;
  try {
  const user = { email, password };
  console.log(user,"user");
    const token = createToken(user);
    res.status(201).json({ token });
  } catch (err) {
    res.status(400).json({ error: 'User already exists' });
  }
};

exports.location =  async (req, res) => {
    const { type } = req.query;
    const { locationID } = req.params;
  
    let response = {
      success: true,
      message: "",
      data: {},
    };
  
    try {
      if (locationID) {
        const objController = new PublicAlerts();
        const objLocation = await objController.loadLocationById(req, res, {
          locationId: locationID,
          type: -1,
        });
  
        if (
          objLocation &&
          objLocation.locations &&
          Array.isArray(objLocation.locations) &&
          objLocation.locations.length > 0
        ) {
          const loc = objLocation.locations[0];
          const locationResponse = {
            id: loc.id,
            name: loc.name,
            logo: loc.logo,
            address: loc.address,
            latitude: loc.latitude,
            longitude: loc.longitude,
            polygon: loc.polygon,
            radius: loc.radius,
            zoom: loc.zoom,
          };
  
          response.data = locationResponse;
  
          const parsedType = parseInt(type);
  
          switch (parsedType) {
            case 2:
              const geoTiffData = {}; // Replace with real data
              response.data.floors = geoTiffData;
              break;
            case 3:
              const centegixData = {
                floors: [],
                assets: [],
                labels: [],
              };
              response.data.floors = centegixData.floors;
              response.data.assets = centegixData.assets;
              response.data.labels = centegixData.labels;
              break;
            case 4:
              const geoCommData = {};
              response.data.site = geoCommData;
              break;
            default:
              const { url } = req.query;
              if (url) {
                const filePath = path.join(__dirname, "public", url);
                if (fs.existsSync(filePath)) {
                  return res.sendFile(filePath);
                } else {
                  response.success = false;
                  response.message = "File not found.";
                }
              }
              break;
          }
        } else {
          response.success = false;
          response.message = "Location not found.";
        }
      } else {
        response.success = false;
        response.message = "Location ID is required.";
      }
    } catch (error) {
      console.error("Error:", error);
      response.success = false;
      response.message = "Internal Server Error";
    }
  
    return res.status(200).json(response);
  };
